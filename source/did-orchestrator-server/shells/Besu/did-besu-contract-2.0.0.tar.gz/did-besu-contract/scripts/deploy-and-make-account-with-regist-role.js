const { ethers, upgrades, config } = require("hardhat");

async function deployContract() {
   try {
       const DocumentStorage = await ethers.getContractFactory(
           "DocumentStorage",
       );
       const documentStorage = await DocumentStorage.deploy();
       const documentStorageAddress = await documentStorage.getAddress();
       console.log("DocumentStorage deployed to:", documentStorageAddress);

       const VcMetaStorage = await ethers.getContractFactory(
           "VcMetaStorage",
       );
       const vcMetaStorage = await VcMetaStorage.deploy();
       const vcMetaStorageAddress = await vcMetaStorage.getAddress();
       console.log("VcMetaStorage deployed to:", vcMetaStorageAddress);

       const ZKPStorage = await ethers.getContractFactory(
           "ZKPStorage",
       );
       const zkpStorage = await ZKPStorage.deploy();
       const zkpStorageAddress = await zkpStorage.getAddress();
       console.log("ZKPStorage deployed to:", zkpStorageAddress);

       const MultibaseContract = await ethers.getContractFactory(
           "MultibaseContract",
       );
       const multibaseContract = await MultibaseContract.deploy();
       const multibaseContractAddress = await multibaseContract.getAddress();
       console.log("MultibaseContract deployed to:", multibaseContractAddress);

       const OpenDID = await ethers.getContractFactory(
           "OpenDID",
       );

       const openDIDProxy = await upgrades.deployProxy(OpenDID, [
           documentStorageAddress,
           vcMetaStorageAddress,
           zkpStorageAddress,
           multibaseContractAddress
       ], {
           kind: "uups",
       });

       await openDIDProxy.waitForDeployment();

       const contractAddress = await openDIDProxy.getAddress();
       console.log("OpenDID deployed to:", contractAddress);

       const implementationAddress =
           await upgrades.erc1967.getImplementationAddress(contractAddress);
       console.log("Implementation address:", implementationAddress);

       return {
           proxy: contractAddress,
           implementation: implementationAddress,
           contract: openDIDProxy
       };
   } catch (error) {
       console.error("Deployment failed:", error);
       throw error;
   }
}

async function callRegistRole(contractAddress, targetAddress, roleType) {
   try {
       console.log("\n=== Calling registRole function ===");

       // Get contract instance
       const OpenDID = await ethers.getContractFactory("OpenDID");
       const openDIDContract = OpenDID.attach(contractAddress);

       // Call registRole function
       console.log(`Granting role "${roleType}" to address: ${targetAddress}`);
       const tx = await openDIDContract.registRole(targetAddress, roleType);

       console.log("Transaction hash:", tx.hash);
       console.log("Waiting for transaction confirmation...");

       const receipt = await tx.wait();
       console.log("Transaction confirmed in block:", receipt.blockNumber);

       // Verify that the role was granted successfully
       const hasRole = await openDIDContract.isHaveRole(targetAddress, roleType);
       console.log(`Role verification - ${targetAddress} has role "${roleType}": ${hasRole}`);

       return receipt;
   } catch (error) {
       console.error("registRole failed:", error);
       throw error;
   }
}

async function checkRole(contractAddress, targetAddress, roleType) {
   try {
       console.log("\n=== Checking role ===");

       const OpenDID = await ethers.getContractFactory("OpenDID");
       const openDIDContract = OpenDID.attach(contractAddress);

       const hasRole = await openDIDContract.isHaveRole(targetAddress, roleType);
       console.log(`Address ${targetAddress} has role "${roleType}": ${hasRole}`);

       return hasRole;
   } catch (error) {
       console.error("Role check failed:", error);
       throw error;
   }
}

async function main() {
   const [owner] = await ethers.getSigners();
   console.log("Deploying the contract with the account:", await owner.getAddress());

   try {
       // 1. Deploy contracts
       const { proxy: contractAddress, contract } = await deployContract();

       // 2. Create Ethereum Wallets
       const fs = require('fs');
       const forge = require('node-forge');
       const { Wallet } = require('ethers');

       const pemTas = fs.readFileSync('./scripts/tas_besu_pkcs8.pem', 'utf8');
       const base64Tas = pemTas
       .replace(/-----(BEGIN|END) (EC|PRIVATE) KEY-----/g, '')
       .replace(/\s+/g, '');
       const derTas = Buffer.from(base64Tas, 'base64');

       const privatekeyHexTas = derTas.slice(-32).toString('hex');

       const tasWallet = new Wallet('0x' + privatekeyHexTas, ethers.provider);
       console.log('== TAS Ethereum Wallet ==');
       console.log('Address: ' + tasWallet.address);
       console.log('Private Key TAS: ' + tasWallet.privateKey);

       const pemIssuer = fs.readFileSync('./scripts/issuer_besu_pkcs8.pem', 'utf8');
       const base64Issuer = pemIssuer
       .replace(/-----(BEGIN|END) (EC|PRIVATE) KEY-----/g, '')
       .replace(/\s+/g, '');
       const derIssuer = Buffer.from(base64Issuer, 'base64');

       const privatekeyHexIssuer = derIssuer.slice(-32).toString('hex');

       const issuerWallet = new Wallet('0x' + privatekeyHexIssuer, ethers.provider);
       console.log('== Issuer Ethereum Wallet ==');
       console.log('Address: ' + issuerWallet.address);
       console.log('Private Key Issuer: ' + issuerWallet.privateKey);

       // 3. Assign roles
       console.log("\n=== Role Assignment Examples ===");

       // 3-1: Grant "Tas" role to tasWallet
       await callRegistRole(
           contractAddress,
           tasWallet.address,
           "Tas"
       );

       // 3-2: Grant "Issuer" role to issuerWallet
       await callRegistRole(
           contractAddress,
           issuerWallet.address,
           "Issuer"
       );

       // 4. Verify roles
       console.log("\n=== Final Role Check ===");
       await checkRole(contractAddress, tasWallet.address, "Tas");
       await checkRole(contractAddress, issuerWallet.address, "Issuer");

       console.log("\n=== Script completed successfully ===");

   } catch (error) {
       console.error("Script failed:", error);
       process.exit(1);
   }
}

main().then(() => process.exit(0))
   .catch(error => {
       console.error(error);
       process.exit(1);
   });

module.exports = {
   deployContract,
   callRegistRole,
   checkRole
};