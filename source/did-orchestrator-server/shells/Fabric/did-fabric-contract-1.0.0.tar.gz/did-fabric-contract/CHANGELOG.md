# Changelog

## v1.0.0 (2024-10-18)

### 🚀 New Features

- DID Document transaction management
- VerifiableCredential Metadata transaction management
