# License Information

### This project uses the following third-party libraries, each under its own license:

<br>

**Btcutil: ISC License**  
`github.com/btcsuite/btcutil v1.0.2`  
(http://github.com/btcsuite/btcutil)

<br>

**CCKit: Apache License 2.0**  
`github.com/hyperledger-labs/cckit v1.0.5`  
(http://github.com/hyperledger-labs/cckit)

<br>

**Fabric Chaincode Go: Apache License 2.0**  
`github.com/hyperledger/fabric-chaincode-go v0.0.0-20240704073638-9fb89180dc17`  
(http://github.com/hyperledger/fabric-chaincode-go)

<br>

**Validator.v9: MIT License**  
`gopkg.in/go-playground/validator.v9 v9.31.0`  
(https://github.com/go-playground/validator)